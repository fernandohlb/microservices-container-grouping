(function (){
  'use strict';

  module.exports = {
    session: {
      secret: 'sooper secret',
      resave: false,
      saveUninitialized: true
    }
  };
}());
